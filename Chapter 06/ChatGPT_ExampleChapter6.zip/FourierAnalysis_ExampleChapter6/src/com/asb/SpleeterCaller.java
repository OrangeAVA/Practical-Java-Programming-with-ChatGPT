package com.asb;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;   // ASB added for the correct call for the Java ProcessBuilder
import java.util.List;        // ASB added for the correct call for the Java ProcessBuilder
public class SpleeterCaller {
    public static void main(String[] args) {
        try {
            //String pythonScriptPath = "path/to/spleeter_separate.py"; // Replace with actual path
        	String pythonScriptPath = "/usr/local/lib64/python3.6/site-packages/spleeter_separate.py"; //ASB Our Path to the python script
            //String inputFile = "path/to/input.mp4"; // Replace with actual input file path
            //String inputFile = "/usr/local/lib64/python3.6/site-packages/audio_example.mp3";           // ASB Our input file path
            String inputFile = "/usr/local/lib64/python3.6/site-packages/Three_Lions_Footballs_Coming_Home-641522.mp3";           // ASB Our input file path
           //String outputDirectory = "path/to/output/"; // Replace with desired output directory
            String outputDirectory = "ASBoutput";             // ASB our output directory
            
            // Construct the command to execute the Python script
            /* ASB Software Development Limited - This section of Java code, suggested by ChatGPT is incorrect
             * 									  The String[] array is not acceptable to ProcessBuilder, it requires an ArrayList
             */
            //String[] command = {"python", pythonScriptPath, inputFile, outputDirectory};
            //
            //ASB We don't need the python script file suggested by ChatGPT, we can call spleeter directly using the command
            // spleeter separate -p spleeter:2stems -o output audio_example.mp3
             
            List<String> command = new ArrayList<String>();  // ASB we actually need a List interface, rather than a String array
            command.add ("/usr/local/bin/spleeter");         // ASB command name
            command.add ("separate");                        // ASB arguments are added as separate list items
            command.add ("-p");                                 
            command.add("spleeter:2stems");
            command.add ("-o" + outputDirectory);            
            command.add (inputFile);                         
           
           ProcessBuilder processBuilder = new ProcessBuilder(command);
            processBuilder.redirectErrorStream(true);           
            Process process = processBuilder.start();
            
            // Read the output of the Python script
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            
            // Wait for the process to complete
            int exitCode = process.waitFor();
            System.out.println("Python script exited with code: " + exitCode);
            
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

