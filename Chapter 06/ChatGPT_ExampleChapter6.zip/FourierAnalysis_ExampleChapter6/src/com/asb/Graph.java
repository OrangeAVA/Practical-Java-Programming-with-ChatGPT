package com.asb;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Graph {
    public static void main(String[] args) {
        double[] values = {1.0, 2.0, 3.0, 4.0};
        XYSeries series = new XYSeries("XYGraph");
        for (int i = 0; i < values.length; i++) {
            series.add(i + 1, values[i]);
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        JFreeChart chart = ChartFactory.createXYLineChart(
                "XY Graph",
                "X-Axis",
                "Y-Axis",
                dataset);
        ChartFrame frame = new ChartFrame("First", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
