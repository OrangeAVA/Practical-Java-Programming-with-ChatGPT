package com.asb;

import javax.sound.sampled.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jtransforms.fft.FloatFFT_2D;
import java.io.*;                      // ASB This import was missing and is required for the File("input.mp4") code line

public class AudioAnalysis {
    public static void main(String[] args) {
        try {
        	//ASB Updated the test file from input.mp4
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("/usr/local/lib64/python3.6/site-packages/output/audio_example/vocals.wav"));
            AudioFormat format = audioInputStream.getFormat();
            
            // Read and process audio data in chunks
            int chunkSize = 2048; // Adjust as needed //ASB Adjusted Chunk size down from 2048
            byte[] audioData = new byte[chunkSize]; 
            // final float[] actual = new float[2 * numRows * numCols];
            FloatFFT_2D fft = new FloatFFT_2D(chunkSize, 2); //ASB need to increase the columns parameter to greater than 1            
            // Process each chunk of audio data
            Boolean nodata = true;
            int screen_count = 0;
            while (audioInputStream.read(audioData) != -1 & screen_count < 5 ) {
                int bytes = audioInputStream.read(audioData);
                System.out.println("Byte size:" + bytes) ;
                float[] audioSamples = convertBytesToFloats(audioData);
                System.out.println("Array size:" + audioSamples.length) ;
               // Apply FFT
                float[] spectrum = new float[chunkSize/2]; //Changed from 2*chunksize array must be of size rows*2*columns, with only the first rows*columns
                for (int j=0; j <  audioSamples.length; j++) {
                	spectrum[j] = audioSamples[j];
                	if (audioSamples[j] > 0.0f) {
                		nodata = false;
                	}
                	
                }
                //System.arraycopy(audioSamples, 0, spectrum, 0, chunkSize); //ASB changed to chunkSize/2
               //ASB Now display the Fourier Transform array
                if(!nodata) {
                    // fft.realForwardFull(spectrum); //ASB Gives OutOfBounds Exception Index 1024 out of bounds for length 1024
                    
                    // Process the spectrum data (e.g., separate sources)
                    
                    // Inverse FFT to reconstruct audio
                    // fft.realInverseFull(audioSamples, true); //ASB  Gives OutOfBounds Exception Index 1024 out of bounds for length 1024
     
                	screen_count++;
                	XYSeries series2 = new XYSeries("XYGraph");
                	for (int i = 0; i < spectrum.length; i++) {
                		series2.add(i + 1, spectrum[i]); // The Fourier Transform data set is added for the Graph
                	}
                	XYSeriesCollection dataset2 = new XYSeriesCollection();
                	dataset2.addSeries(series2);
                	JFreeChart chart2 = ChartFactory.createXYLineChart(
                        "Fourier Analysis of an Audio .wav File - Audio Data plot",
                        "X-Axis",
                        "Y-Axis",
                        dataset2);
                	ChartFrame frame2 = new ChartFrame("Using ChatGPT AudioAnalysis.java", chart2);
                	frame2.pack();
                	frame2.setVisible(true); 
                	Thread.sleep(5000);
                // Process the reconstructed audio (e.g., post-processing)
               frame2.dispose();
                }
                nodata = true; 
            }
            
            audioInputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static float[] convertBytesToFloats(byte[] bytes) {
        float[] floats = new float[bytes.length / 2];
        for (int i = 0; i < floats.length; i++) {
            floats[i] = (float) ((bytes[2 * i] & 0xFF) | (bytes[2 * i + 1] << 8));
        }
        return floats;
    }
}
