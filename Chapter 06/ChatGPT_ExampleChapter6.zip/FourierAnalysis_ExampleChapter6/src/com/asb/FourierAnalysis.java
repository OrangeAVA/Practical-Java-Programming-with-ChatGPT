package com.asb;

import java.util.Arrays;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class FourierAnalysis {
    
    public static void main(String[] args) {
        
        // Define the sine wave
        double[] signal = new double[1024];
        for (int i = 0; i < signal.length; i++) {
            signal[i] = Math.sin(2 * Math.PI * i / 32);
        }
        
        // Compute the Fourier transform
        double[] spectrum = computeSpectrum(signal);
        
        // Print the spectrum
        for (int i = 0; i < spectrum.length; i++) {
            System.out.println(i + "\t" + spectrum[i]);
        }
        //ASB Additional code to Graph the results of the Sine Curve Fourier Analysis
        XYSeries series = new XYSeries("XYGraph");
        for (int i = 0; i < signal.length; i++) {
            series.add(i + 1, signal[i]); // 
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Fourier Analysis of a Sine Curve - signal plot",
                "X-Axis",
                "Y-Axis",
                dataset);
        ChartFrame frame = new ChartFrame("Using ChatGPT FourierAnalysis.java", chart);
        frame.pack();
        frame.setVisible(true);
        //ASB Now display the Fourier Transform array
        XYSeries series2 = new XYSeries("XYGraph");
        for (int i = 0; i < spectrum.length; i++) {
            series2.add(i + 1, spectrum[i]); // The Fourier Transform data set is added for the Graph
        }
        XYSeriesCollection dataset2 = new XYSeriesCollection();
        dataset2.addSeries(series2);
        JFreeChart chart2 = ChartFactory.createXYLineChart(
                "Fourier Analysis of a Sine Curve - Transform plot",
                "X-Axis",
                "Y-Axis",
                dataset2);
        ChartFrame frame2 = new ChartFrame("Using ChatGPT FourierAnalysis.java", chart2);
        frame2.pack();
        frame2.setVisible(true);

        
    }
    
    public static double[] computeSpectrum(double[] signal) {
        int n = signal.length;
        double[] spectrum = new double[n];
        for (int i = 0; i < n; i++) {
            double re = 0;
            double im = 0;
            for (int j = 0; j < n; j++) {
                double angle = 2 * Math.PI * i * j / n;
                re += signal[j] * Math.cos(angle);
                im -= signal[j] * Math.sin(angle);
            }
            spectrum[i] = Math.sqrt(re * re + im * im) / n;
        }
        return spectrum;
    }
}
