/**
 * 
 */
/**
 * 
 */
module FourierAnalysis_ExampleChapter6 {
	requires org.jfree.jfreechart;
	requires javax.sound;
	requires JTransforms;
	requires java.desktop;
	requires junit;
	requires xuggle.xuggler;
}