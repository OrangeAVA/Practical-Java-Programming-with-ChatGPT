package com.asb;

public class PolynomialInversion {
    public static double[] invertTriangularMatrix(double[][] matrix) {
        int n = matrix.length;
        double[] coefficients = new double[n];
        for (int i = n - 1; i >= 0; i--) {
            double sum = 0;
            for (int j = i + 1; j < n; j++) {
                sum += matrix[i][j] * coefficients[j];
            }
            coefficients[i] = (matrix[i][n] - sum) / matrix[i][i];
        }
        return coefficients;
    }
    public static void main(String[] args) {
    	/*  ASB we try the following matrix
    	 *  1  0  0   2
    	 *  0  1  0   3 
    	 *  0  0  1  -1
    	 * ASB Replacing the original AI code:
    	 */ 
        /*double[][] matrix = {
            {1, 0, 0, 1},
            {0, 1, 0, 2},
            {0, 0, 1, 3}
        };
        */
        double[][] matrix = {
        {1, 0, 0, 2},
        {0, 1, 0, 3},
        {0, 0, 1,-1}
        };
        double[] coefficients = invertTriangularMatrix(matrix);
        System.out.println("Coefficients of the polynomial:");
        for (int i = 0; i < coefficients.length; i++) {
            System.out.println("x^" + i + ": " + coefficients[i]);
        }
    }
}

