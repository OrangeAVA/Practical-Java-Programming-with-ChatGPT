package com.asb;

import java.util.Scanner;

public class PolynomialSolver {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get the degree of the polynomial
        System.out.print("Enter the degree of the polynomial: ");
        int n = scanner.nextInt();
        
        // Create the matrix of coefficients
        double[][] matrix = new double[n+1][n+2];
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= n; j++) {
                System.out.print("Enter the coefficient of x^" + (n-j) + " in equation " + (i+1) + ": ");
                matrix[i][j] = scanner.nextDouble();
            }
            System.out.print("Enter the result of equation " + (i+1) + ": ");
            matrix[i][n+1] = scanner.nextDouble();
        }
        
        // Invert the matrix
        for (int i = n; i >= 0; i--) {
            double divisor = matrix[i][i];
            for (int j = 0; j <= n+1; j++) {
                matrix[i][j] /= divisor;
            }
            for (int j = i-1; j >= 0; j--) {
                double factor = matrix[j][i]; //ASB
                for (int k = 0; k <= n+1; k++) {
                    matrix[j][k] -= factor * matrix[i][k];
                }
            }
        }
        
        // Print the solution
        //ASB Changed to use x, y, z rather than 
        System.out.println("\nPolynomial coefficients:");
        for (int i = 0; i <= n; i++) {
            System.out.println("x^" + (n-i) + " = " + String.format("%.2f", matrix[i][n+1]));
        }
        //ASB We add code to fix the scanner Resource Leak warning
        scanner.close();
    }
}