package com.asb;

import Jama.Matrix;

public class TriangularMatrixInversionExample {
    public static void main(String[] args) {
        // Define your coefficients matrix A here (lower triangular part)
        double[][] coefficients = {
            {1.0, 0.0, 0.0},
            {2.0, 3.0, 0.0},
            {4.0, 5.0, 6.0}
        };

        // Create a matrix from the coefficients
        Matrix A = new Matrix(coefficients);

        // Calculate the inverse of the lower triangular matrix
        Matrix LInverse = A.inverse();

        // Define your polynomial equation result vector B here (upper triangular part)
        double[][] polynomialResults = {
            {10.0},
            {20.0},
            {30.0}
        };

        // Create a matrix from the polynomial results
        Matrix B = new Matrix(polynomialResults);

        // Solve for the coefficients using the inverted lower triangular matrix
        Matrix coefficientsVector = LInverse.times(B);

        // Print the resulting coefficients vector
        coefficientsVector.print(5, 2);
    }
}
