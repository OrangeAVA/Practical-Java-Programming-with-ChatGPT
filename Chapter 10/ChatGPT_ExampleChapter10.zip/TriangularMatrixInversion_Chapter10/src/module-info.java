/**
 * 
 */
/**
 * 
 */
module TriangularMatrixInversion_Chapter10 {
	requires Jama;
}