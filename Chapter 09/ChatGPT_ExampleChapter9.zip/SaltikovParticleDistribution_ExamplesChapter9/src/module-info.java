/**
 * 
 */
/**
 * 
 */
module SaltikovParticleDistribution_ExamplesChapter9 {
	requires commons.math3;
	requires org.jfree.jfreechart;
}