package com.asb;
import java.util.Scanner;

public class Saltikov {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get the number of sections measured
        System.out.print("Enter the number of sections measured: ");
        int n = scanner.nextInt();
        
        // Get the section size measurements
        double[] sizes = new double[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Enter the size of section " + (i+1) + " in micrometers: ");
            sizes[i] = scanner.nextDouble();
        }
        
        // Get the area under the curve
        System.out.print("Enter the area under the curve: ");
        double area = scanner.nextDouble();
        System.out.println("Enter the area under the curve: =" + area);
        // Calculate the particle size distribution
        double[] distribution = new double[n];
        for (int i = 0; i < n; i++) {
            double x = sizes[i];
            double y = area / sizes[i];           //ASB This makes 2 * x * y which is used later a constant value of 2 * area
            double z = 2.0f * y * x;              //ASB Which makes the calculated distribution a constant value independent of
                                                  //ASB each of the section particle sizes.
                                                  //ASB The distribution is therefore a constant value just dependent on the area entered
            System.out.println("y =" + y + ", x=" + x + " 2.0f * y * x =" +z ); //ASB Debug added here
            distribution[i] = Math.exp(-2.0f * y * x);
        }
       
        // Print the particle size distribution
        System.out.println("\nParticle size distribution:");
        for (int i = 0; i < n; i++) {
            System.out.println(String.format("%.2f", sizes[i]) + " um: " + String.format("%.8f", distribution[i]));
        }
        //ASB We correct the warning by closing the scanner input
        scanner.close();
    }
}
