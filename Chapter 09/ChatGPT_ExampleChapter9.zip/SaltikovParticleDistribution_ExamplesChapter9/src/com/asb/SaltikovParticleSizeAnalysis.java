package com.asb;

import java.util.ArrayList;
import java.util.List;

public class SaltikovParticleSizeAnalysis {
    
    public static void main(String[] args) {
        // Example input data - section size distribution
        List<Double> sectionSizes = new ArrayList<>();
        sectionSizes.add(0.5);
        sectionSizes.add(1.0);
        sectionSizes.add(1.5);
        sectionSizes.add(2.0);
        sectionSizes.add(2.5);
        sectionSizes.add(3.0);
        
        // Parameters for Saltikov determination
        double thickness = 0.1; // Thickness of the material
        double shapeFactor = 0.9; // Shape factor for the particles
        
        // Perform Saltikov determination
        List<Double> particleSizes = calculateParticleSizes(sectionSizes, thickness, shapeFactor);
        
        // Output the results
        System.out.println("Particle Size Distribution:");
        for (double size : particleSizes) {
            System.out.println(size);
        }
    }
    
    /**
     * Calculates the particle size distribution based on the Saltikov determination.
     *
     * @param sectionSizes   List of section sizes
     * @param thickness      Thickness of the material
     * @param shapeFactor    Shape factor for the particles
     * @return List of particle sizes
     */
    public static List<Double> calculateParticleSizes(List<Double> sectionSizes, double thickness, double shapeFactor) {
        List<Double> particleSizes = new ArrayList<>();
        
        for (double sectionSize : sectionSizes) {
            // Calculate the particle size using the Saltikov determination formula
            double particleSize = Math.sqrt((8 * thickness * sectionSize) / (Math.PI * shapeFactor));
            particleSizes.add(particleSize);
        }
        
        return particleSizes;
    }
}
