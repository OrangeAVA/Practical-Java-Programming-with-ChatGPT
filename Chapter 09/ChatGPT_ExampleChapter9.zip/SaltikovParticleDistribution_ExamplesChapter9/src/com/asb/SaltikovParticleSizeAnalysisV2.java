package com.asb;

import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
//ASB Added Graph Imports
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
//ASB 

import java.util.ArrayList;
import java.util.List;

public class SaltikovParticleSizeAnalysisV2 {
    
    public static void main(String[] args) {
        // Example input data - section size distribution
        List<Double> sectionSizes = new ArrayList<>();
        sectionSizes.add(0.5);
        sectionSizes.add(1.0);
        sectionSizes.add(1.5);
        sectionSizes.add(2.0);
        sectionSizes.add(2.5);
        sectionSizes.add(3.0);
       
        // Parameters for Saltikov determination
        double thickness = 0.1; // Thickness of the material
        double shapeFactor = 0.9; // Shape factor for the particles
        
        // Perform Saltikov determination
        List<Double> particleSizes = calculateParticleSizes(sectionSizes, thickness, shapeFactor);
        
        // Output the results
        System.out.println("Particle Size Distribution:");
        for (double size : particleSizes) {
            System.out.println(size);
        }
        //ASB Now display the Particle Distribution array
        XYSeries series = new XYSeries("XYGraph");
        for (int i = 0; i < particleSizes.size(); i++) {
            series.add(i + 1, particleSizes.get(i)); // The Fourier Transform data set is added for the Graph
        }
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Saltikov Particle Distribution - Using Matrix Calculation",
                "X-Axis - Size in µmetres",
                "Y-Axis - Number of particles",
                dataset);
        ChartFrame frame = new ChartFrame("Using ChatGPT SaltykovParticleAnalysisV2.java", chart);
        frame.pack();
        frame.setVisible(true);

    }
    
    /**
     * Calculates the particle size distribution based on the Saltikov determination.
     *
     * @param sectionSizes List of section sizes
     * @param thickness Thickness of the material
     * @param shapeFactor Shape factor for the particles
     * @return List of particle sizes
     */
    public static List<Double> calculateParticleSizes(List<Double> sectionSizes, double thickness, double shapeFactor) {
        int n = sectionSizes.size();
        
        // Create the matrix A
        double[][] aData = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                aData[i][j] = Math.pow(sectionSizes.get(i), 2 * j + 1);
            }
        }
        RealMatrix aMatrix = new Array2DRowRealMatrix(aData);
        System.out.println("A Matrix:" + aMatrix.toString()); //ASB Added to debug the final results given
                
        // Create the vector b
        double[] bData = new double[n];
        for (int i = 0; i < n; i++) {
            bData[i] = Math.pow(sectionSizes.get(i), 2 * i + 1);//ASB Changed from n to i otherwise, n is a static 13, which would make nonsense of the other calculations given in the code
        }
        RealMatrix bVector = MatrixUtils.createColumnRealMatrix(bData);
        System.out.println("B Vector Matrix:" + bVector.toString()); //ASB Added to debug the final results given       
        try {
            // Perform matrix inversion to solve for x
            RealMatrix xMatrix = MatrixUtils.inverse(aMatrix).multiply(bVector); 
            System.out.println("Inverse Matrix:" + xMatrix.toString()); //ASB Added to debug the final results given
            
            // Extract the particle sizes from the solution vector x            
            double[] xData = xMatrix.getColumn(0); 
            List<Double> particleSizes = new ArrayList<>();
            for (double value : xData) {
                //ASB Use the ABs function to see the impact of calculated values (otherwise we are using  some negatives which give NaN)  
            	//ASB This affects 0.5, 1.5, and 2.5 which give NaN without this line of code
            	value = Math.abs(value);
                double particleSize = Math.sqrt((8 * thickness * value) / (Math.PI * shapeFactor));
                particleSizes.add(particleSize);
            }
            
            return particleSizes;
        } catch (SingularMatrixException e) {
            // Matrix inversion failed due to a singular matrix
            System.out.println("Matrix inversion failed. The section sizes may not be suitable for analysis.");
            return null;
        }
    }
}