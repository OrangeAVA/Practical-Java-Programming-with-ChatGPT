/**
 * 
 */
/**
 * 
 */
module IBMFilenetDocuments_Chapter11 {
	requires Jace;
}