package com.asb;
//ASB There are no Java I/O classes imported which we need to have to load a byte stream from our text document
import java.io.BufferedReader;    //ASB Added for File I/O
import java.io.File;			  //ASB Added for File I/O
import java.io.FileInputStream;   //ASB Added for File I/O
import java.io.FileNotFoundException;
import java.io.FileOutputStream;  //ASB Added for File I/O
import java.io.IOException;		  //ASB Added for File I/O
import java.io.InputStreamReader; //ASB Added for File I/O

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode; //ASB Needed to add this missing import
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.util.UserContext;
//import com.ibm.filenet.api.util.CEConnection; //ASB we needed to change this import
import com.filenet.api.core.Connection;

public class FileNetDocumentStorageExample {

    public static void main(String[] args) {
    	Domain dom; //ASB We need this object for retrieving the Object Store
        // Connection parameters
        String uri = "http://ecmukdemo22:9080/wsi/FNCEWS40MTOM/"; //ASB Changed to our Server name, ecmukdemo22 from localhost
        String username = "p8admin";        					  //ASB your_username changed to p8admin
        String password = "filenet";        					  //ASB your password changed to filenet
        String stanza = "FileNetP8WSI";     				 	  //ASB Added this for the FileNet WSI connection type
        String WcmApiConfigPath = "/opt/IBM/FileNet/CEClient/config/jaas.conf.WSI";  //ASB Added this for the FileNet WSI Path
        // Document properties
        String documentPath = "/AVA_Orange_Test";               //ASB Changed to our TOS1 ObjectStore test folder /AVA_Orange_Test
        String documentFilePath = "/root/eclipse/eclipse";      //ASB Added for the Linux server test document folder path 
        String documentName = "example_document.txt";           //ASB created using the vi editor
        String documentContent = "This is the content of the document."; //ASB Not used, we use a real document here and create a byte stream 

        // Establish connection to FileNet
        //ASB There is a whole helper Java source class missing, usually provided by downloading the IBM FileNet supporting .zip file
        //ASB DenoJava.zip file Found on 
        //ASB https://www.ibm.com/support/pages/filenet-content-engine-java-api-demo-sample-code 
        //ASB Also, the method is incorrect,  getCEConnection(uri) was changed to the call
        //ASB establishConnection(userName, password, stanza, uri)
        //Connection connection = CEConnection.getCEConnection(uri); //ASB Original AI code
        CEConnection connection = new CEConnection();
		connection.establishConnection(username, password, stanza, uri, WcmApiConfigPath);
        //UserContext.get().pushSubject(UserContext.createSubject(connection, username, password, null));//ASB not required now

        try {
            // Get the Object Store
            //ObjectStore objectStore = Factory.ObjectStore.fetchInstance(connection, "your_object_store", null); //ASB This needs to be re-factored
        	ObjectStore objectStore  =  connection.fetchOS("TOS1");//ASB replacement code also changed the "your_object_store"

            // Get the target folder
            Folder targetFolder = Factory.Folder.fetchInstance(objectStore, documentPath, null);

            // Create a new document
            Document document = Factory.Document.createInstance(objectStore, null);

            // Set document properties
            document.getProperties().putValue("DocumentTitle", documentName);
            document.set_MimeType("text/plain");

            // Create a content element list
            ContentElementList contentList = Factory.ContentElement.createList();

            // Create a content transfer object
            ContentTransfer contentTransfer = Factory.ContentTransfer.createInstance();
            // ASB We need to load the document file
            FileInputStream is = null;
    		try {
    			is = new FileInputStream(documentFilePath + File.separator + documentName);
    		}
    		catch (FileNotFoundException e){
    			 e.printStackTrace();
    			 }
    		catch (IOException e){
    			
    		}
            // Set the content of the document
            //contentTransfer.setCaptureSource(null); // ASB Needed a non-null vallue here ;
            contentTransfer.setCaptureSource(is);   // ASB This can't be a String , so we changed documentContent to is
            contentTransfer.set_ContentType("text/plain");
            contentTransfer.set_RetrievalName(documentName);
            contentList.add(contentTransfer);

            // Set the content of the document
            document.set_ContentElements(contentList);
            document.save(RefreshMode.REFRESH);
            // File the document in the target folder
            // ASB This code doesn't work, we need another Java method , folderDoc, to link our  FileNet Document object to the Object Store Folder           
            
            //document.file(targetFolder, null, null, null);//ASB replaced with a method call
            folderDoc(document,targetFolder,documentName, objectStore);
            // Save the document
            document.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);            
            document.save(RefreshMode.REFRESH);

            System.out.println("Document stored successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Disconnect from FileNet
            UserContext.get().popSubject();
        }
    }
    private static void folderDoc(Document doc, Folder folder, String documentTitle, ObjectStore os) {
    	//ASB We had to write a new method to link the IBM FileNet Document Object to the ObjectStore Folder object.
    	try {
    		com.filenet.api.core.ReferentialContainmentRelationship rcr = folder.file(doc,
    				AutoUniqueName.AUTO_UNIQUE, null, DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
    		rcr.set_ContainmentName(documentTitle);
    		rcr.save(RefreshMode.NO_REFRESH);
    	}
    	catch(Exception e) {
    		
    	}
    }

}

