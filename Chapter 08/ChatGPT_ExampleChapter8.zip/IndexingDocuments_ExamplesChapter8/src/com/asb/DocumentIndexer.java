package com.asb;

import java.io.IOException;
import java.nio.file.Paths;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class DocumentIndexer {
  private Directory indexDir;

  public DocumentIndexer(String indexDirectoryPath) throws IOException {
    indexDir = FSDirectory.open(Paths.get(indexDirectoryPath));
  }

  public void indexDocument(String documentPath, String[] keywords) throws IOException {
    IndexWriterConfig indexWriterConfig = new IndexWriterConfig(new StandardAnalyzer());
    //ASB we found we needed to do this to preserve previously run Indexing
    indexWriterConfig.setOpenMode(IndexWriterConfig.OpenMode.CREATE_OR_APPEND);
    try (IndexWriter indexWriter = new IndexWriter(indexDir, indexWriterConfig)) {
      Document document = new Document();
      document.add(new TextField("path", documentPath, Field.Store.YES));
      for (String keyword : keywords) {
        document.add(new TextField("keyword", keyword, Field.Store.YES));
      }
      indexWriter.addDocument(document);
    }
  }

  public void searchDocuments(String[] keywords) throws Exception {
    IndexReader indexReader = DirectoryReader.open(indexDir);
    IndexSearcher indexSearcher = new IndexSearcher(indexReader);

    QueryParser queryParser = new MultiFieldQueryParser(new String[] {"keyword"}, new StandardAnalyzer());
    Query query = queryParser.parse(String.join(" ", keywords));

    TopDocs topDocs = indexSearcher.search(query, 10);

    for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
      Document document = indexSearcher.doc(scoreDoc.doc);
      System.out.println("Page: " + document.get("path"));
    }

    indexReader.close();
  }

  public static void main(String[] args) throws Exception {
    //String indexDirectoryPath = "/path/to/index/directory";//ASB We use the path to the new index directory we are building
    String indexDirectoryPath = "/opt/AVA/index/directory";
    DocumentIndexer indexer = new DocumentIndexer(indexDirectoryPath);
    //String documentPath = "/path/to/document";             //ASB We use the path to the Chapter 6 document we created                   
    String documentPath = "/opt/AVA/Chapters/chapter6";                 
    String[] keywords = {"xuggler", "Jfreechart", "mp3"};    //ASB Was set as "keyword1", "keyword2", "keyword3"
    indexer.indexDocument(documentPath, keywords);

    String[] searchKeywords = {"Commons", "mp3"};            //ASB Was set as "keyword1", "keyword3"
    indexer.searchDocuments(searchKeywords);
  }
}
