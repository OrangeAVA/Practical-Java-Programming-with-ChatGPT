package com.asb;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.BaseDirectory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import java.net.URI;
import java.nio.file.Paths;

//import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.analysis.standard.StandardAnalyzer;

public class LuceneIndexer {
    public void indexDocument(String text, int pageNumber) throws Exception {
        //Directory indexDirectory = new RAMDirectory();                             //ASB This doesn't work
    	String indexDirectoryPath = "/opt/AVA/index/directory"; 
		FSDirectory indexDirectory = FSDirectory.open(Paths.get(indexDirectoryPath));
        IndexWriterConfig config = new IndexWriterConfig(new StandardAnalyzer());
        IndexWriter writer = new IndexWriter(indexDirectory, config);

        Document document = new Document();
        document.add(new StringField("text", text, Field.Store.YES));
        document.add(new StringField("pageNumber", Integer.toString(pageNumber), Field.Store.YES));
        writer.addDocument(document);
        writer.close();
    }
}

