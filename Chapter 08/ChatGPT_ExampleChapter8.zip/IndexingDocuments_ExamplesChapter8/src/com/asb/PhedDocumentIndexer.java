package com.asb;
//This was the basic example given, but there is no main to test the code
import java.util.ArrayList;//ASB We needed to add this import
import java.util.HashMap;  //ASB We needed to add this import
import java.util.List;     //ASB We needed to add this import
import java.util.Map;      //ASB We needed to add this import

public class PhedDocumentIndexer {
    private Map<String, List<Integer>> index = new HashMap<>();

    public void indexDocument(String document, int pageNumber) {
        String[] words = document.toLowerCase().split("\\W+");
        for (String word : words) {
            if (!index.containsKey(word)) {
                index.put(word, new ArrayList<>());
            }
            index.get(word).add(pageNumber);
        }
    }

    public List<Integer> getPageNumbers(String word) {
        return index.get(word.toLowerCase());
    }
}

