package com.asb;

import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
public class BookIndexer {
	public class Index {
	    public Index(Readable text) {
	        Scanner sc = new Scanner(text);
	        occurences = new HashMap<String, ArrayList<Integer>>();

	        int lineNo = 1;
	        try {
	            while (sc.hasNextLine()) {
	                String line = sc.nextLine();
	                String[] words = line.split("\\W+");
	                for (String word : words) {
	                    word = word.toLowerCase();
	                    ArrayList<Integer> list = occurences.get(word);
	                    if (list == null) {
	                        list = new ArrayList<>();
	                        list.add(lineNo);
	                    } else {
	                        list.add(lineNo);
	                    }
	                    occurences.put(word, list);
	                }
	                lineNo++;
	            }
	        } finally {
	            sc.close();
	        }
	    }
    public static void main(String[] args) throws IOException {
        Reader br = getReader(args);
        String indexStr = getOccurencesMap(br).toString();
        System.out.println(indexStr);
    }

    private static Reader getReader(String[] args) {
        if (args.length == 0) {
            return new BufferedReader(new InputStreamReader(System.in));
        } else {
            try {
                return new BufferedReader(new FileReader(args[0]));
            } catch (FileNotFoundException e) {
                throw new IllegalArgumentException("The given file does not exist.", e);
            }
        }
    }

    private static Map<String, List<Integer>> getOccurencesMap(Reader text) throws IOException {
        try (LineNumberReader reader = new LineNumberReader(text)) {
            return reader.lines()
                         .flatMap(Pattern.compile("\\s+")::splitAsStream)
                         .map(w -> w.toLowerCase(Locale.ROOT))
                         .collect(Collectors.groupingBy(
                             w -> w,
                             Collectors.mapping(w -> reader.getLineNumber(), Collectors.toList())
                         ));
        }
    }
    public String toString() {
        return occurences.toString();
    }
    private Map<String, ArrayList<Integer>> occurences;
}
}

