package com.asb;

import java.nio.file.Paths;

import org.apache.lucene.analysis.standard.StandardAnalyzer;//ASB We had to add this import statement
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;                  //ASB We had to add this import statement
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.queryparser.classic.QueryParser;

public class LuceneSearcher {
    public TopDocs searchIndex(Directory indexDirectory, String keyword) throws Exception {
        IndexReader reader = DirectoryReader.open(indexDirectory);
        IndexSearcher searcher = new IndexSearcher(reader);
        int numdocs = reader.numDocs();     //ASB we added this for debug
        System.out.println("Number of documents in the Index = " + Integer.toString(numdocs)); //ASB See if we have any documents
        QueryParser parser = new QueryParser("keyword", new StandardAnalyzer()); //ASB Changed from text to keyword
        Query query = parser.parse(keyword); //ASB This adds the keyword as  lower case, so mp3 and MP3 are searched as mp3
        System.out.println("Query =" + query.toString() ); //ASB Added for debug       
        TopDocs results = searcher.search(query, 10);
        return results; 
    }
    //ASB We added the main from the Ask AI example modified for this LucenSearcher method
    public static void main(String[] args) throws Exception {
        Directory indexDir;
       //String indexDirectoryPath = "/path/to/index/directory";//ASB We use the path to the new index directory we are building
        String indexDirectoryPath = "/opt/AVA/index/directory"; // index/directory
        indexDir = FSDirectory.open(Paths.get(indexDirectoryPath));
        //DocumentIndexer indexer = new DocumentIndexer(indexDirectoryPath);
        LuceneSearcher indexer = new LuceneSearcher();
        //String documentPath = "/path/to/document";             //ASB We use the path to the Chapter 6 document we created                   
        String keyword = "mp3";    //ASB Was set as "keyword1", "keyword2", "keyword3"
        TopDocs results = indexer.searchIndex(indexDir, keyword);
        //ASB Print the Results array
        System.out.println("Results =" + results.scoreDocs.length);
        for (int i = 0; i < results.scoreDocs.length; i++) {
        	System.out.println(Integer.toString(i)  +".  "+results.scoreDocs[i] );
            //String documentString = results.scoreDocs[i].toString();
            //System.out.println("Docstring = " + documentString);

        }

      }
}
