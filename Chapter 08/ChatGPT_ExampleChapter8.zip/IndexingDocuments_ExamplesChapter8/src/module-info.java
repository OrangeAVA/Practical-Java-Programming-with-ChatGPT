/**
 * 
 */
/**
 * 
 */
module IndexingDocuments_ExamplesChapter8 {
	requires org.apache.lucene.core;
	requires org.apache.lucene.queryparser;
	requires org.apache.lucene.queries;   //ASB We added this line because of the Runtime error
	requires org.apache.lucene.sandbox;   //ASB We added this line because of the Runtime error
	requires org.apache.lucene.memory;    //ASB Added for RAMDirectory
}