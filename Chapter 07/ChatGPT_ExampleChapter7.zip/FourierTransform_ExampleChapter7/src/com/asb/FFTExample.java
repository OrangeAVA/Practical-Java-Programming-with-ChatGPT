package com.asb;

import org.apache.commons.math3.complex.Complex;

import org.apache.commons.math3.transform.DftNormalization; //ASB This was required to satisfy the constructor type argument  in the code body below
import org.apache.commons.math3.transform.FastFourierTransformer;
import org.apache.commons.math3.transform.TransformType;    //ASB This was required to satisfy the constructor type argument
//ASB Added for plotting an additional example
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class FFTExample {

    public static void main(String[] args) {
        double[] input = {1.0, 2.0, 3.0, 4.0};
        //FastFourierTransformer transformer = new FastFourierTransformer();   //ASB the original code was found to be missing an argument
        FastFourierTransformer transformer = new FastFourierTransformer(DftNormalization.STANDARD); //ASB an argument was required for the correct syntax
        //Complex[] output = transformer.transform(input);           		                   //ASB the original code was found to be missing an argument
        Complex[] output = transformer.transform(input, TransformType.FORWARD);				   //ASB an argument was required for the correct syntax

        System.out.println("Input:");
        for (double d : input) {
            System.out.print(d + " ");
        }
        System.out.println("\nOutput:");
        for (Complex c : output) {
            System.out.print(c + " ");
        }
        /*
         * ASB Software Development Limited
         * We have developed a more interesting example based on the following
         * w = 10*2*pi
			From t = 0 to 0.5 in steps of .001
			Sum n = 1 to 4 n* cos (n * w * t)
			See:
			https://en.wikipedia.org/wiki/Fast_Fourier_transform
			Note: Java stores the value of pi as a constant, or 3.141592653589793
         */
        double[] yval = new double[4096]; // ASB Note that this array size has to be a power of two
        int j=0;
        double sum = 0.0f;
        final double PI = 3.14159265358979323846;
        double t=0.0f;
        double w = 10.0f *2.0f  *PI;
         	for (int i =0 ;  i <   1000 ; i++) {
         		t += 0.001; //Increment t by 1/1000 each time
         		//Calculate the sum
         		for (int n = 1; n < 5; n++) {
         			j++;
         			sum = sum + Math.cos(n*w*t);//Try exp for an interesting result.
         			yval[j] = sum;
         		}
       	
         	}
         	// ASB Plot the values using our Graph code 
            XYSeries series = new XYSeries("XYGraph");
            for (int i = 0; i < yval.length; i++) {
                series.add(i + 1, yval[i]); // 
            }
            XYSeriesCollection dataset = new XYSeriesCollection();
            dataset.addSeries(series);
            JFreeChart chart = ChartFactory.createXYLineChart(
                    "Fourier Analysis of a Complex Sine Curve - signal plot",
                    "X-Axis",
                    "Y-Axis",
                    dataset);
            ChartFrame frame = new ChartFrame("Using ChatGPT FourierAnalysis.java", chart);
            frame.pack();
            frame.setVisible(true);
            //ASB Set up the FFT
            FastFourierTransformer transformer2 = new FastFourierTransformer(DftNormalization.STANDARD); //ASB an argument was required for the correct syntax
            Complex[] output2 = transformer.transform(yval, TransformType.FORWARD);				   //ASB an argument was required for the correct syntax
            double[] real = new double[output2.length];
            double[] imaginary = new double[output2.length];
            //Populate our FFT results into two parts
            for(int i=0; i<real.length; ++i) {
              real[i] = output2[i].getReal();
              imaginary[i] = output2[i].getImaginary();
            }
        	// ASB Plot the imaginary values using our Graph code - Real plot
            XYSeries series2 = new XYSeries("XYGraph");
            for (int i = 0; i < imaginary.length; i++) {
                series2.add(i + 1, imaginary[i]); // 
            }
            XYSeriesCollection dataset2 = new XYSeriesCollection();
            dataset2.addSeries(series2);
            JFreeChart chart2 = ChartFactory.createXYLineChart(
                    "Fourier Analysis of a Complex Sine Curve - Imaginary part FFT plot",
                    "X-Axis",
                    "Y-Axis",
                    dataset2);
            ChartFrame frame2 = new ChartFrame("Using ChatGPT FFTExample.java", chart2);
            frame2.pack();
            frame2.setVisible(true);
        	// ASB Plot the Real values using our Graph code - Real plot
            XYSeries series3 = new XYSeries("XYGraph");
            for (int i = 0; i < real.length; i++) {
                series3.add(i + 1, real[i]); // 
            }
            XYSeriesCollection dataset3 = new XYSeriesCollection();
            dataset3.addSeries(series3);
            JFreeChart chart3 = ChartFactory.createXYLineChart(
                    "Fourier Analysis of a Complex Sine Curve - Real part FFT plot",
                    "X-Axis",
                    "Y-Axis",
                    dataset3);
            ChartFrame frame3 = new ChartFrame("Using ChatGPT FFTExample.java", chart3);
            frame3.pack();
            frame3.setVisible(true);

 
    }
    
}
