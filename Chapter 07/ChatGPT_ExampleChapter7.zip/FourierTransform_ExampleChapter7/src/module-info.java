/**
 * 
 */
/**
 * 
 */
module FourierTransform_ExampleChapter7 {
	requires commons.math3;
	requires org.jfree.jfreechart;
}